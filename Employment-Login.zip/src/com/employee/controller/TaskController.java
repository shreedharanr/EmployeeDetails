package com.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.employee.bean.TaskBean;
import com.employee.model.Task;
import com.employee.service.TaskService;

@Controller
public class TaskController {

	@Autowired 
	private TaskService taskservice;

	@RequestMapping(value="/addTask", method = RequestMethod.GET)
	public ModelAndView addTask() {	
		return new ModelAndView("addTask");
		
	}
	
	@RequestMapping(value="/saveTask", method = RequestMethod.POST)
	public ModelAndView saveTask(TaskBean taskBean, 
			BindingResult result) {
		Task task = prepareModel(taskBean);
		taskservice.addTask(task);
		System.out.println(task.getUserName());
		System.out.println("Status Is >>>>>>>>>>>>>>>>"+ task.getTaskStatus());
		return new ModelAndView("login");
		
	}
	
	private Task prepareModel(TaskBean taskBean){
		Task task = new Task();
		task.setUserName(taskBean.getName());
		task.setTaskStatus(taskBean.getStatus());
		taskBean.setId(null);
		return task;
	}
	
}
