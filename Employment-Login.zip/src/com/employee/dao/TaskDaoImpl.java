package com.employee.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.employee.model.Task;

@Repository("taskDao")
public class TaskDaoImpl implements TaskDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	public void addTask(Task task) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(task);
		
	}

}
