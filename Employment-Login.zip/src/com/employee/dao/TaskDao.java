package com.employee.dao;

import com.employee.model.Task;

public interface TaskDao {

	public void addTask(Task task);

}