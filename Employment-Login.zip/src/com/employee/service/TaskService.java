package com.employee.service;

import com.employee.model.Task;

public interface TaskService {
	public void addTask(Task task);

}
